#ifndef MENU_H
#define MENU_H

int menu();

#endif
