#include <stdlib.h>ls




    SDL_Surface *ecran = NULL, *image = NULL;

Mix_Music* backgroundSound = NULL ;




Mix_Chunk* boutton;




Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024);

backgroundSound = Mix_LoadMUS("philia.mp3");















    SDL_Rect positionFond,positionClic;




    positionFond.x = 0;

    positionFond.y = 0;

boutton=Mix_LoadWAV("723.wav");







 ecran = SDL_SetVideoMode(600, 400, 32, SDL_HWSURFACE|SDL_DOUBLEBUF);

image= IMG_Load("QUIT.png");

SDL_BlitSurface(image, NULL, ecran, &positionFond);




        SDL_Flip(ecran);




    SDL_Init(SDL_INIT_EVERYTHING);






   // ecran = SDL_SetVideoMode(600, 400, 32, SDL_HWSURFACE|SDL_DOUBLEBUF);







    int i=1,x;




    int continuer = 1;

    //bool done;

    SDL_Event event;

Mix_PlayMusic(backgroundSound,-1);



    while (continuer)

    {

        x=0;

        SDL_WaitEvent(&event);

        switch(event.type)

        {

        case SDL_QUIT:

            continuer = 0;

            break;







        case SDL_KEYDOWN:




            switch(event.key.keysym.sym)




            {




            case SDLK_LEFT:

Mix_PlayChannel(-1,boutton,0);

                if (i==1)

                    i=2;




                else

                  i=1;






                break;




            case SDLK_RIGHT:

Mix_PlayChannel(-1,boutton,0);




                if(i==1)

                    i=2;




                else










                    i=1;

                break;




            }

             case SDL_MOUSEMOTION:

            if (event.motion.x>40 && event.motion.x<90 && event.motion.y>305 && event.motion.y<325)

            {

                i=1;




            }




            else if (event.motion.x>500 && event.motion.x<550 && event.motion.y>305 && event.motion.y<325)

            {

                i=2;


            }

            break;



        }







        //les images des boutons




        if(i==1)

        {

            image= IMG_Load("yes.png");




        }




        if(i==2)

        {

            image= IMG_Load("no.png");




        }
if(i==1){
switch(e.type)
        {
            case SDL_QUIT:
                continuer = 0;
                break;
            case SDL_MOUSEBUTTONDOWN:
                switch(e.button.button)
                {
                    case SDL_BUTTON_LEFT:
                         
                     continuer =0;
                     
                 
                 break;
                     }
break;
                      }
}

        SDL_BlitSurface(image, NULL, ecran, &positionFond);




        SDL_Flip(ecran);







        //aprés apuis des boutons




        }








    SDL_FreeSurface(image);

Mix_FreeChunk(boutton);

Mix_FreeMusic(backgroundSound);

Mix_CloseAudio();


    SDL_Quit();






    return;



}

