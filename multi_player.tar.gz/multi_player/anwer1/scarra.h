#ifndef SCARRA_H
#define SCARRA_H

int play();

#endif
