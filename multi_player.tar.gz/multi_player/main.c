#include <stdlib.h>
#include <stdio.h>
#include "menu.h"
#include "scarra.h"

void main()
{
	int ___ = 15;
	while(___ != 4)
	{
		___ = menu();
		if(___ = 1)
		{
			play();
		}
	}
}
