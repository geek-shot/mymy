#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "scarra.h"


void pause();
int check_collision( SDL_Rect A, SDL_Rect B );

int play()
{

	SDL_Surface *ecran = NULL, *imagedefond = NULL, *detec = NULL,*sandoug = NULL;
	
	SDL_Surface *imagedefond1 = NULL, *detec1 = NULL,*sandoug1 = NULL;

	SDL_Surface *anwer[2][8];
	SDL_Surface *zombie[2][4];

	SDL_Surface *anwer1[2][8];
	SDL_Surface *zombie1[2][4];

	int anwerD = 0, anwerA = 0,i;
	int zombieD = 0, zombieA = 0;

	int anwerD1 = 0, anwerA1 = 0;
	int zombieD1 = 0, zombieA1 = 0;
	int zzz=0;
	
	char imgname[50];
	SDL_Rect positionfond, positiondetec,pos_sandoug;

	SDL_Rect positionfond1, positiondetec1,pos_sandoug1;

	int continu = 1 ;
	int done=1;
	SDL_Event event;

	SDL_Rect camera;
	camera.x = 0;
	camera.y = 0;
	camera.h = 700;
	camera.w = 1000;

	SDL_Rect camera1;
	camera1.x = 0;
	camera1.y = 300;
	camera1.h = 700;
	camera1.w = 1000;

	positionfond.x= 0;
	positionfond.y= 0;
	positiondetec.x=50;
	positiondetec.y=360;	
	positiondetec.h = 150;
	positiondetec.w = 90;

	positionfond1.x= 0;
	positionfond1.y= 0;
	positiondetec1.x=50;
	positiondetec1.y=60;	
	positiondetec1.h = 150;
	positiondetec1.w = 90;

	SDL_Rect poszombie;
	poszombie.x = 1500;
	poszombie.y = 360;
	
	SDL_Rect poszombie1;
	poszombie1.x = 1500;
	poszombie1.y = 60;

	SDL_Init(SDL_INIT_VIDEO);
	
	ecran = SDL_SetVideoMode(1000,700,32,SDL_HWSURFACE);
	SDL_WM_SetCaption("lanwer bond",NULL);
		
	for(i=0;i<4;i++)
	{
		sprintf(imgname,"zombie/_%d.png",i+1);
		zombie[0][i] = IMG_Load(imgname);
		sprintf(imgname,"zombie/%d_.png",i+1);
		zombie[1][i] = IMG_Load(imgname);
	}
	
	for(i=0;i<8;i++)
	{
		sprintf(imgname,"anwer_d%d.png",i);
		anwer[0][i] = IMG_Load(imgname);
		sprintf(imgname,"anwer_g%d.png",i);
		anwer[1][i] = IMG_Load(imgname);
	}

	for(i=0;i<4;i++)
	{
		sprintf(imgname,"zombie/_%d.png",i+1);
		zombie1[0][i] = IMG_Load(imgname);
		sprintf(imgname,"zombie/%d_.png",i+1);
		zombie1[1][i] = IMG_Load(imgname);
	}
	
	for(i=0;i<8;i++)
	{
		sprintf(imgname,"anwer_d%d.png",i);
		anwer1[0][i] = IMG_Load(imgname);
		sprintf(imgname,"anwer_g%d.png",i);
		anwer1[1][i] = IMG_Load(imgname);
	}
	
	pos_sandoug.x = 500;
	pos_sandoug.y = 435;
	pos_sandoug.h = 60;
	pos_sandoug.w = 65;

	pos_sandoug1.x = 500;
	pos_sandoug1.y = 135;
	pos_sandoug1.h = 60;
	pos_sandoug1.w = 65;
	
	sandoug = IMG_Load("sandoug.png");
	imagedefond = IMG_Load("niveau1.png");

	sandoug1 = IMG_Load("sandoug.png");
	imagedefond1 = IMG_Load("niveau1.png");
	
	//SDL_BlitSurface(imagedefond,NULL,ecran,&positionfond);
	
	detec = IMG_Load("anwer.png");
	imagedefond = IMG_Load("niveau1.png");

	detec1 = IMG_Load("anwer.png");
	imagedefond1 = IMG_Load("niveau1.png");
	

	//SDL_SetColorKey(detec,SDL_SRCCOLORKEY,SDL_MapRGB(detec->format,255,255,255));
	SDL_EnableKeyRepeat(80,80);
	while (done)
	{

	while (continu)
	{
		SDL_WaitEvent(&event);
		switch(event.type)
		{
			case SDL_QUIT :
				continu = 0;
				break;
			case SDL_KEYDOWN:
	
				switch(event.key.keysym.sym)
				{
					case SDLK_UP :
				
						positiondetec.y=positiondetec.y-20;
if (positiondetec.y <= 0){ positiondetec.y=0;}

					
						break;
					case SDLK_DOWN : 

						positiondetec.y=positiondetec.y+20;
if (positiondetec.y == 480){ positiondetec.y=0;}
						break;
					case SDLK_RIGHT : 
                                                  if(anwerD == 1 || !check_collision(positiondetec,pos_sandoug))
					{
						positiondetec.x=positiondetec.x+20;
//if (positiondetec.x==340){ positiondetec.x=0;}

							anwerD = 0;	
						
						anwerA++;
						if(anwerA > 7)
							anwerA = 0;
						
						if(positiondetec.x > 500) {
							positiondetec.x = 500;
							camera.x+=20;
							pos_sandoug.x-=20;
						}
					}
						poszombie.x-=20;
						break;
					case SDLK_LEFT : 
						
//if (positiondetec.x <=0 ){ positiondetec.x=0;}

						if(anwerD == 0 || !check_collision(positiondetec,pos_sandoug))
					{	anwerD = 1;
						anwerA++;
						if(anwerA > 7)
							anwerA = 0;

						camera.x-=20;
						pos_sandoug.x+=20;
						/*if(pos_sandoug.x > 435)
						{
							pos_sandoug.x = 435;
						}*/	
						if(camera.x < 0) {
							camera.x = 0;
							positiondetec.x=positiondetec.x-20;
							pos_sandoug.x = 500;
						}
					}
						poszombie.x+=20;
						break;
					case SDLK_SPACE :
						positiondetec.y = positiondetec.y - 30;

						SDL_Delay(250);
						positiondetec.y=positiondetec.y+30;

						break;
//*************************************************************************************************************************************
					case SDLK_d :
						  if(anwerD1 == 1 || !check_collision(positiondetec1,pos_sandoug1))
					{
						positiondetec1.x=positiondetec1.x+20;
//if (positiondetec.x==340){ positiondetec.x=0;}

							anwerD1 = 0;	
						
						anwerA1++;
						if(anwerA1 > 7)
							anwerA1 = 0;
						
						if(positiondetec1.x > 500) {
							positiondetec1.x = 500;
							camera1.x+=20;
							pos_sandoug1.x-=20;
						}
					}
						poszombie1.x-=20;
						break;
					case SDLK_q :
						if(anwerD1 == 0 || !check_collision(positiondetec1,pos_sandoug1))
					{	anwerD1 = 1;
						anwerA1++;
						if(anwerA1 > 7)
							anwerA1 = 0;

						camera1.x-=20;
						pos_sandoug1.x+=20;
						/*if(pos_sandoug.x > 435)
						{
							pos_sandoug.x = 435;
						}*/	
						if(camera1.x < 0) {
							camera1.x = 0;
							positiondetec1.x=positiondetec1.x-20;
							pos_sandoug1.x = 500;
						}
					}
						poszombie1.x+=20;
						break;
				} 
				break;
	}
	if( zombieD = 0 )
	{
//		poszombie.x+=10;
		zzz++;
		zombieA++;
		if(zzz > 8 )
		{
			zombieD = 1;
		}
		if(zombieA > 3 )
		{
			zombieA = 0;
		}
	}
	else
	{
//		poszombie.x-=10;
		zzz++;
		zombieA++;
		if(zzz > 8 )
		{
			zombieD = 1;
		}
		if(zombieA > 3 )
		{
			zombieA = 0;
		}
	}
	if( zombieD1 = 0 )
	{
//		poszombie.x+=10;
		zzz++;
		zombieA1++;
		if(zzz > 8 )
		{
			zombieD1 = 1;
		}
		if(zombieA1 > 3 )
		{
			zombieA1 = 0;
		}
	}
	else
	{
//		poszombie.x-=10;
		zzz++;
		zombieA1++;
		if(zzz > 8 )
		{
			zombieD1 = 1;
		}
		if(zombieA1 > 3 )
		{
			zombieA1 = 0;
		}
	}

	//imagedefond = IMG_Load("niveau1.png");
	
	SDL_BlitSurface(imagedefond,&camera,ecran,&positionfond);

	//if( poszombie.x - camera.x < 1000 ) 
	//{
		SDL_BlitSurface(zombie[zombieD][zombieA],NULL,ecran,&poszombie);
	//}

	
	SDL_BlitSurface(anwer[anwerD][anwerA],NULL,ecran,&positiondetec);
	
	if( pos_sandoug.x > 0 ){SDL_BlitSurface(sandoug,NULL,ecran,&pos_sandoug);}

	
	SDL_BlitSurface(imagedefond1,&camera1,ecran,&positionfond1);

	//if( poszombie.x - camera.x < 1000 ) 
	//{
		SDL_BlitSurface(zombie1[zombieD1][zombieA1],NULL,ecran,&poszombie1);
	//}

	
	SDL_BlitSurface(anwer1[anwerD1][anwerA1],NULL,ecran,&positiondetec1);
	
	if( pos_sandoug1.x > 0 ){SDL_BlitSurface(sandoug1,NULL,ecran,&pos_sandoug1);}

	SDL_Flip(ecran);
	
}	
	if (Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024)==-1)
	{
		printf("%s",Mix_GetError());
	}
	Mix_Music*music;
	music=Mix_LoadMUS("music.mp3");
	Mix_PlayMusic(music,-1);

	Mix_FreeMusic(music);
	}

	
	for(i=0;i<8;i++)
	{
	//	SDL_FreeSurface(anwer[0][i]);
	//	SDL_FreeSurface(anwer[1][i]);
	}
	
	//SDL_FreeSurface(imagedefond);
	
	//SDL_FreeSurface(detec);
	SDL_Quit();

	return EXIT_SUCCESS;
}

int check_collision( SDL_Rect A, SDL_Rect B )
{
    //Les cotes des rectangles
    int leftA, leftB;
    int rightA, rightB;
    int topA, topB;
    int bottomA, bottomB;
 
    //Calcul les cotes du rectangle A
    leftA = A.x;
    rightA = A.x + A.w;
    topA = A.y;
    bottomA = A.y + A.h;
 
    //Calcul les cotes du rectangle B
    leftB = B.x;
    rightB = B.x + B.w;
    topB = B.y;
    bottomB = B.y + B.h;

 if( bottomA <= topB )
    {
        return 0;
    }
 
    if( topA >= bottomB )
    {
        return 0;
    }
 
    if( rightA <= leftB )
    {
        return 0;
    }
 
    if( leftA >= rightB )
    {
        return 0;
    }
 
    //Si conditions collision detectee
    return 1;
}

void pause(){

	int continuer=1;
	SDL_Event event;
	while (continuer)
	{
		SDL_WaitEvent(&event);
		switch(event.type)
		{
			case SDL_QUIT :
			continuer=0;
}
}
}
