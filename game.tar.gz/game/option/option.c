#include <stdlib.h>


#include <stdio.h>

#include <SDL/SDL.h>

#include <SDL/SDL_mixer.h>

#include <SDL/SDL_image.h>

void main()




{




    SDL_Surface *ecran = NULL, *image = NULL;

Mix_Music* backgroundSound = NULL ;




Mix_Chunk* boutton;




Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024);

backgroundSound = Mix_LoadMUS("philia.mp3");




  










    SDL_Rect positionFond,positionClic;




    positionFond.x = 0;

    positionFond.y = 0;

boutton=Mix_LoadWAV("723.wav");







 ecran = SDL_SetVideoMode(600, 400, 32, SDL_HWSURFACE|SDL_DOUBLEBUF);

image= IMG_Load("9.png");

SDL_BlitSurface(image, NULL, ecran, &positionFond);




        SDL_Flip(ecran);




    SDL_Init(SDL_INIT_EVERYTHING);




    

   // ecran = SDL_SetVideoMode(600, 400, 32, SDL_HWSURFACE|SDL_DOUBLEBUF);







    int i=6,x;




    int continuer = 1;

    //bool done;

    SDL_Event event;

Mix_PlayMusic(backgroundSound,-1);

   

    while (continuer)

    {

        x=0;

        SDL_WaitEvent(&event);

        switch(event.type)

        {

        case SDL_QUIT:

            continuer = 0;

            break;







        case SDL_KEYDOWN:




            switch(event.key.keysym.sym)




            {




            case SDLK_LEFT:

Mix_PlayChannel(-1,boutton,0);

                if (i==1)

                    i=1;




                else







                    i--;

                break;




            case SDLK_RIGHT:

Mix_PlayChannel(-1,boutton,0);




                if(i==6)

                    i=6;




                else










                    i++;

                break;




            }
       

        }







        //les images des boutons




        if(i==1)

        {

            image= IMG_Load("mute.png");




        }




        if(i==2)

        {

            image= IMG_Load("1.png");




        }

        if(i==3)

        {

            image = IMG_Load("3.png");




        }

        if(i==4)

        {

            image = IMG_Load("5.png");







        }
if(i==5)

        {

            image = IMG_Load("8.png");
}
if(i==6)

        {

            image = IMG_Load("9.png");

      }

        SDL_BlitSurface(image, NULL, ecran, &positionFond);




        SDL_Flip(ecran);







        //aprés apuis des boutons




        }

        

        




    SDL_FreeSurface(image);

Mix_FreeChunk(boutton);

Mix_FreeMusic(backgroundSound);

Mix_CloseAudio();

   

    

  

    SDL_Quit();

            




    return;

            

}


