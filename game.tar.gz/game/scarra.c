#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "scarra.h"


void pause();
int check_collision( SDL_Rect A, SDL_Rect B );
void savegame();
void loadgame();
void save_nogame();

int play()
{

	SDL_Surface *ecran = NULL, *imagedefond = NULL, *detec = NULL,*sandoug = NULL,*sandoug1 = NULL;
	SDL_Surface *anwer[2][8];
	SDL_Surface *zombie[2][4];
	SDL_Surface *save[3];

	save[0] = IMG_Load("save_.png");
	save[1] = IMG_Load("save_yes.png");
	save[2] = IMG_Load("save_no.png");

	int anwerD = 0, anwerA = 0,i;
	int zombieD = 0, zombieA = 0;
	int zzz=0;
	int save_ = 0,blabla = 1;

	char imgname[50];
	SDL_Rect positionfond, positiondetec,pos_sandoug,pos_sandoug1;
	int continu = 1 ;
	int done=1;
	SDL_Event event;

	SDL_Rect camera;
	camera.x = 0;
	camera.y = 0;
	camera.h = 700;
	camera.w = 1000;

	positionfond.x= 0;
	positionfond.y= 0;
	positiondetec.x=50;
	positiondetec.y=360;	
	positiondetec.h = 150;
	positiondetec.w = 90;

	SDL_Rect poszombie;
	poszombie.x = 1500;
	poszombie.y = 360;
	poszombie.h = 150;
	poszombie.w = 90;

	SDL_Init(SDL_INIT_VIDEO);
	
	ecran = SDL_SetVideoMode(1000,700,32,SDL_HWSURFACE);
	SDL_WM_SetCaption("lanwer bond",NULL);
		
	for(i=0;i<4;i++)
	{
		sprintf(imgname,"zombie/_%d.png",i+1);
		zombie[0][i] = IMG_Load(imgname);
		sprintf(imgname,"zombie/%d_.png",i+1);
		zombie[1][i] = IMG_Load(imgname);
	}
	
	for(i=0;i<8;i++)
	{
		sprintf(imgname,"anwer_d%d.png",i);
		anwer[0][i] = IMG_Load(imgname);
		sprintf(imgname,"anwer_g%d.png",i);
		anwer[1][i] = IMG_Load(imgname);
	}
	
	pos_sandoug.x = 500;
	pos_sandoug.y = 435;
	pos_sandoug.h = 60;
	pos_sandoug.w = 65;

	pos_sandoug1.x = 1000;
	pos_sandoug1.y = 435;
	pos_sandoug1.h = 60;
	pos_sandoug1.w = 65;
	
	sandoug = IMG_Load("sandoug.png");
	sandoug1 = IMG_Load("sandoug.png");
	imagedefond = IMG_Load("niveau1.png");
	
	//SDL_BlitSurface(imagedefond,NULL,ecran,&positionfond);
	
	detec = IMG_Load("anwer.png");
	imagedefond = IMG_Load("niveau1.png");
	

	//SDL_SetColorKey(detec,SDL_SRCCOLORKEY,SDL_MapRGB(detec->format,255,255,255));
	SDL_EnableKeyRepeat(80,80);

	loadgame(&positiondetec,&pos_sandoug,&pos_sandoug1,&camera);

	while (done)
	{

	while (continu)
	{
		SDL_WaitEvent(&event);
		switch(event.type)
		{
			case SDL_QUIT :
				continu = 0;
done = 0;
				break;
			case SDL_KEYDOWN:
	
				switch(event.key.keysym.sym)
				{
					case SDLK_UP :
				
						positiondetec.y=positiondetec.y-20;
if (positiondetec.y <= 0){ positiondetec.y=0;}

					
						break;
					case SDLK_DOWN : 

						positiondetec.y=positiondetec.y+20;
if (positiondetec.y == 480){ positiondetec.y=0;}
						break;
					case SDLK_RIGHT : 
                  if(anwerD == 1 || (!check_collision(positiondetec,pos_sandoug) && !check_collision(positiondetec,pos_sandoug1)))
					{
						positiondetec.x=positiondetec.x+20;
//if (positiondetec.x==340){ positiondetec.x=0;}

							anwerD = 0;	
						
						anwerA++;
						if(anwerA > 7)
							anwerA = 0;
						
						if(positiondetec.x > 500) {
							positiondetec.x = 500;
							camera.x+=20;
							pos_sandoug.x-=20;
							pos_sandoug1.x-=20;
						}
					}
						poszombie.x-=20;
						break;
					case SDLK_LEFT : 
						
//if (positiondetec.x <=0 ){ positiondetec.x=0;}

						if(anwerD == 0 || (!check_collision(positiondetec,pos_sandoug) && !check_collision(positiondetec,pos_sandoug1)))
					{	anwerD = 1;
						anwerA++;
						if(anwerA > 7)
							anwerA = 0;

						camera.x-=20;
						pos_sandoug.x+=20;
						pos_sandoug1.x+=20;
						/*if(pos_sandoug.x > 435)
						{
							pos_sandoug.x = 435;
						}*/	
						if(camera.x < 0) {
							camera.x = 0;
							positiondetec.x=positiondetec.x-20;
							pos_sandoug.x = 500;
							pos_sandoug1.x = 1000;
						}
					}
						poszombie.x+=20;
						break;
					case SDLK_SPACE :
						positiondetec.y = positiondetec.y - 30;

						SDL_Delay(250);
						positiondetec.y=positiondetec.y+30;

						break;
				} 
				break;
	}
	if( zombieD = 0 )
	{
//		poszombie.x+=10;
		zzz++;
		zombieA++;
		if(zzz > 8 )
		{
			zombieD = 1;
		}
		if(zombieA > 3 )
		{
			zombieA = 0;
		}
	}
	else
	{
//		poszombie.x-=10;
		zzz++;
		zombieA++;
		if(zzz > 8 )
		{
			zombieD = 1;
		}
		if(zombieA > 3 )
		{
			zombieA = 0;
		}
	}
	if(continu == 0)
	{
		while(blabla)
		{
			SDL_WaitEvent(&event);
			if(event.key.keysym.sym == SDLK_RIGHT)
			{
				save_ = 2;
			}
			if(event.key.keysym.sym == SDLK_LEFT)
			{
				save_ = 1;
			}
			if (event.key.keysym.sym == SDLK_RETURN)
			{
				if(save_ == 1)
				{
					savegame(positiondetec,pos_sandoug,pos_sandoug1,camera);
				}
				if(save_ == 2)
				{
					save_nogame();
				}
				blabla = 0;
			}
			SDL_BlitSurface(save[save_],NULL,ecran,&positionfond);
			SDL_Flip(ecran);
		}
	}

	//imagedefond = IMG_Load("niveau1.png");
	
	SDL_BlitSurface(imagedefond,&camera,ecran,&positionfond);

	//if( poszombie.x - camera.x < 1000 ) 
	//{
		SDL_BlitSurface(zombie[zombieD][zombieA],NULL,ecran,&poszombie);
	//}

	
	SDL_BlitSurface(anwer[anwerD][anwerA],NULL,ecran,&positiondetec);
	
	if( pos_sandoug.x > 0 ){
		SDL_BlitSurface(sandoug,NULL,ecran,&pos_sandoug);
	}
	if( pos_sandoug1.x > 0 ){
		SDL_BlitSurface(sandoug1,NULL,ecran,&pos_sandoug1);
	}
	if(check_collision( positiondetec, poszombie))
	{
		positiondetec.x = 50;
		positiondetec.y = 360;
		pos_sandoug.x = 500;
		pos_sandoug.y = 435;
		pos_sandoug1.x = 1000;
		pos_sandoug1.y = 435;
		camera.x = 0;
		camera.y = 0;
		poszombie.x = 1500;
		poszombie.y = 360;
	}

	SDL_Flip(ecran);
	
}	
}
	if (Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024)==-1)
	{
		printf("%s",Mix_GetError());
	}
	Mix_Music*music;
	music=Mix_LoadMUS("music.mp3");
	Mix_PlayMusic(music,-1);

	Mix_FreeMusic(music);
	

	
	for(i=0;i<8;i++)
	{
	//	SDL_FreeSurface(anwer[0][i]);
	//	SDL_FreeSurface(anwer[1][i]);
	}
	
	//SDL_FreeSurface(imagedefond);
	
	//SDL_FreeSurface(detec);
	SDL_Quit();

	return EXIT_SUCCESS;
}

int check_collision( SDL_Rect A, SDL_Rect B )
{
    //Les cotes des rectangles
    int leftA, leftB;
    int rightA, rightB;
    int topA, topB;
    int bottomA, bottomB;
 
    //Calcul les cotes du rectangle A
    leftA = A.x;
    rightA = A.x + A.w;
    topA = A.y;
    bottomA = A.y + A.h;
 
    //Calcul les cotes du rectangle B
    leftB = B.x;
    rightB = B.x + B.w;
    topB = B.y;
    bottomB = B.y + B.h;

 if( bottomA <= topB )
    {
        return 0;
    }
 
    if( topA >= bottomB )
    {
        return 0;
    }
 
    if( rightA <= leftB )
    {
        return 0;
    }
 
    if( leftA >= rightB )
    {
        return 0;
    }
 
    //Si conditions collision detectee
    return 1;
}

void pause(){

	int continuer=1;
	SDL_Event event;
	while (continuer)
	{
		SDL_WaitEvent(&event);
		switch(event.type)
		{
			case SDL_QUIT :
			continuer=0;
}
}
}

void savegame(SDL_Rect anwer,SDL_Rect sandoug,SDL_Rect sandougtheni,SDL_Rect camera) 
{
	remove("save.txt");
	FILE *f = NULL;
	f = fopen("save.txt","w");
	if(f == NULL)
	{
		printf("Unable to open Savefile!\n");
	}
	else
	{
		fprintf(f,"%d\n",anwer.x );
		fprintf(f,"%d\n",anwer.y );
		fprintf(f,"%d\n",sandoug.x );
		fprintf(f,"%d\n",sandoug.y );
		fprintf(f,"%d\n",sandougtheni.x );
		fprintf(f,"%d\n",sandougtheni.y );
		fprintf(f,"%d\n",camera.x );
		fprintf(f,"%d\n",camera.y );
	}
	fclose(f);
}

void save_nogame() 
{
	remove("save.txt");
	FILE *f = NULL;
	f = fopen("save.txt","w");
	if(f == NULL)
	{
		printf("Unable to open Savefile!\n");
	}
	else
	{
		fprintf(f,"%d\n",50 );
		fprintf(f,"%d\n",360 );
		fprintf(f,"%d\n",500);
		fprintf(f,"%d\n",435 );
		fprintf(f,"%d\n",1000 );
		fprintf(f,"%d\n",435 );
		fprintf(f,"%d\n",0 );
		fprintf(f,"%d\n",0 );
	}
	fclose(f);
}

void loadgame(SDL_Rect *anwer,SDL_Rect *sandoug,SDL_Rect *sandougtheni,SDL_Rect *camera)
{
	FILE *f = NULL;
	f = fopen("save.txt","r");
	int ax,ay,sx,sy,s1x,s1y,cx,cy;
	if(f == NULL)
	{
		printf("Unable to open Savefile!\n");
	}
	else
	{
		fscanf(f,"%d\n",&ax );
		fscanf(f,"%d\n",&ay );
		fscanf(f,"%d\n",&sx );
		fscanf(f,"%d\n",&sy );
		fscanf(f,"%d\n",&s1x );
		fscanf(f,"%d\n",&s1y );
		fscanf(f,"%d\n",&cx );
		fscanf(f,"%d\n",&cy );

		anwer->x = ax;
		anwer->y = ay;
		sandoug->x = sx;
		sandoug->y = sy;
		sandougtheni->x = s1x;
		sandougtheni->y = s1y;
		camera->x = cx;
		camera->y = cy;
	}
	fclose(f);
}
