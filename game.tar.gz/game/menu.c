#include <stdlib.h>


#include <stdio.h>

#include <SDL/SDL.h>

#include <SDL/SDL_mixer.h>

#include <SDL/SDL_image.h>

#include "scarra.h"

int menu()




{




    SDL_Surface *ecran = NULL, *image = NULL, *option[6], *exit[3];

Mix_Music* backgroundSound = NULL ;




Mix_Chunk* boutton;




Mix_OpenAudio(44100,MIX_DEFAULT_FORMAT,MIX_DEFAULT_CHANNELS,1024);

backgroundSound = Mix_LoadMUS("philia.mp3");




  










    SDL_Rect positionFond,positionClic;




    positionFond.x = 0;

    positionFond.y = 0;

boutton=Mix_LoadWAV("723.wav");







 ecran = SDL_SetVideoMode(600, 400, 32, SDL_HWSURFACE|SDL_DOUBLEBUF);

image= IMG_Load("menuplay.png");

int option_ = 1;
int menu_ = 0;
int exit_ = 0;

exit[0] = IMG_Load("exit/QUIT.png");
exit[1] = IMG_Load("exit/yes.png");
exit[2] = IMG_Load("exit/no.png");

option[0] = IMG_Load("option/mute.png");
option[1] = IMG_Load("option/1.png");
option[2] = IMG_Load("option/3.png");
option[3] = IMG_Load("option/5.png");
option[4] = IMG_Load("option/8.png");
option[5] = IMG_Load("option/9.png");

SDL_BlitSurface(image, NULL, ecran, &positionFond);




        SDL_Flip(ecran);




    SDL_Init(SDL_INIT_EVERYTHING);




    

   // ecran = SDL_SetVideoMode(600, 400, 32, SDL_HWSURFACE|SDL_DOUBLEBUF);







    int i=1,x;




    int continuer = 1;

    //bool done;

    SDL_Event event;

Mix_PlayMusic(backgroundSound,-1);

   

    while (continuer)

    {

        x=0;

        SDL_WaitEvent(&event);

        switch(event.type)

        {

        case SDL_QUIT:

            continuer = 0;

            break;







        case SDL_KEYDOWN:




            switch(event.key.keysym.sym)




            {




            case SDLK_UP:

Mix_PlayChannel(-1,boutton,0);

                if (i==1)

                    i=4;




                else







                    i--;

                break;




            case SDLK_DOWN:

Mix_PlayChannel(-1,boutton,0);




                if(i==4)

                    i=1;




                else










                    i++;

                break;
		case SDLK_RIGHT:
			if(menu_ == 2)
				option_++;
				if(option_ > 5 )
				{
					option_ = 5;
				}
			if(menu_ == 4)
				exit_ = 2;
		break;
		case SDLK_LEFT:
			if(menu_ == 2)
				option_--;
				if(option_ < 0 )
				{
					option_ = 0;
				}
			if(menu_ == 4)
				exit_ = 1;
		break;
		case SDLK_RETURN:
                       	if(i==1)
				menu_ = 1;
						continuer = 0;
			if(i==2)
				menu_ = 2;
			if(i==4)
				menu_ = 4;
			if(menu_ == 4 && exit_ == 1)
				continuer = 0;
			if(menu_ == 4 && exit_ == 2)
				menu_ = 0;
		break;
		case SDLK_ESCAPE:
			if(menu_ == 2)
				menu_ = 0;


            }

             case SDL_MOUSEMOTION:

            if (event.motion.x>238 && event.motion.x<268 && event.motion.y>196 && event.motion.y<214)

            {

                i=1;




            }




            else if (event.motion.x>238 && event.motion.x<392 && event.motion.y>234 && event.motion.y<264)

            {

                i=2;
		




            }

            else if (event.motion.x>238 && event.motion.x<378 && event.motion.y>275 && event.motion.y<295)

            {

                i=3;


            }

            else if (event.motion.x>238 && event.motion.x<331 && event.motion.y>316 && event.motion.y<335)

            {

                i=4;




            }

            break; 
	
		case SDL_MOUSEBUTTONUP:
		if (event.motion.x>238 && event.motion.x<268 && event.motion.y>196 && event.motion.y<214)

            {

                menu_ = 1;
				continuer = 0;
		




            }




            else if (event.motion.x>238 && event.motion.x<392 && event.motion.y>234 && event.motion.y<264)

            {

                menu_ =2;
		




            }

            else if (event.motion.x>238 && event.motion.x<378 && event.motion.y>275 && event.motion.y<295)

            {

                menu_ =3;


            }

            else if (event.motion.x>238 && event.motion.x<331 && event.motion.y>316 && event.motion.y<335)

            {

                menu_ =4;




            }
		break;

       

        }







        //les images des boutons




        if(i==1)

        {
		    SDL_FreeSurface(image);
            image= IMG_Load("menuplay.png");




        }




        if(i==2)

        {
		    SDL_FreeSurface(image);
            image= IMG_Load("menuoption.png");//




        }//

        if(i==3)

        {
		    SDL_FreeSurface(image);
            image = IMG_Load("menucredits.png");




        } 

        if(i==4)

        {
		    SDL_FreeSurface(image);
            image = IMG_Load("menuexit.png");







        }

      
	if(menu_ == 0)
        SDL_BlitSurface(image, NULL, ecran, &positionFond);
	if(menu_ == 2)
        SDL_BlitSurface(option[option_], NULL, ecran, &positionFond);
	if(menu_ == 4)
        SDL_BlitSurface(exit[exit_], NULL, ecran, &positionFond);


        SDL_Flip(ecran);



	/*if(menu_ == 1)
	{
		continuer = 0;
	}*/



        //aprés apuis des boutons

}

	for(i=0; i<6; i++)
	{
		SDL_FreeSurface(option[i]);
	}
	for(i=0; i<3; i++)
	{
		SDL_FreeSurface(exit[i]);
	}

    SDL_FreeSurface(image);

Mix_FreeChunk(boutton);

Mix_FreeMusic(backgroundSound);

Mix_CloseAudio();

   

    

  

    SDL_Quit();

            




    return menu_;

            

}

